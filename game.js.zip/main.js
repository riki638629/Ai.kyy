console.log('Hello World!');
let score = 0;
const box = document.getElementById("box");
const gameArea = document.getElementById("gameArea");
const scoreDisplay = document.getElementById("score");

// Fungsi memindahkan kotak secara acak
function moveBox() {
    let maxX = gameArea.clientWidth - box.clientWidth;
    let maxY = gameArea.clientHeight - box.clientHeight;
    let x = Math.floor(Math.random() * maxX);
    let y = Math.floor(Math.random() * maxY);
    box.style.left = x + "px";
    box.style.top = y + "px";
}

// Klik kotak → tambah skor
box.addEventListener("click", function() {
    score++;
    scoreDisplay.textContent = "Score: " + score;
    moveBox();
});

// Kotak pindah tiap 1 detik
setInterval(moveBox, 1000);

// Posisi awal
moveBox();